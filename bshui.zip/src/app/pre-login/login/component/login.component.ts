import { Component ,OnInit} from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Router} from '@angular/router';
import { loginService } from './../../loginservice/login-service';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
declare var $: any;
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
@Component({
  selector: 'login',
  templateUrl: './../template/login.template.html',
})
export class LoginComponent implements OnInit{
  loginData:any;
  constructor(private _router: Router,private loginService: loginService,private Http:Http,private NotificationsService:NotificationsService){
    this.loginData = {
      userName:'',
      passWord:''
    }
  }
  
  ngOnInit(){
    sessionStorage.setItem('isloggedin','false'); 
  
  }
    login(){   
      
      if(this.loginData.userName == '' || this.loginData.userName == null ){
          alert('Please enter username');         
          return false;
      }
      if(this.loginData.passWord == '' || this.loginData.passWord == null ){
          alert('Please enter password');        
          return false;
      }
      $("#loadingdiv").show();
      this.loginService.login(this.loginData)
      .subscribe((x) => {
        if(x.status	=='Success'){          
          this._router.navigate(['/dashboard']);
          var menu = x.mainMenu;
          sessionStorage.setItem('isloggedin','true');
          sessionStorage.setItem('userName',x.userName);
          sessionStorage.setItem('locationCode',x.locationCode);
          localStorage.setItem('menu',JSON.stringify(menu));
          $('body').addClass('skin-blue sidebar-mini sidebar-collapse'); 
          $('body').removeClass('login-page');
          this.NotificationsService.success('Login','Login successfully',{timeOut: 3000, clickToClose: true});
          $("#loadingdiv").hide();
        }else{
          this.NotificationsService.error('Login failed','Username and password does not match',{timeOut: 3000, clickToClose: true});
          $("#loadingdiv").hide();
        }       
      });
            
    }
}
