import { RouterModule } from '@angular/router';
import {LoginComponent} from './login/component/login.component';

export const routing = RouterModule.forRoot([
    {                                          // removed square bracket
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    }, {                                          // removed square bracket
        path: 'login',       
        component: LoginComponent
    }
  ]);