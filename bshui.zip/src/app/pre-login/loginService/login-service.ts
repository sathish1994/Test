import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { ActivatedRoute } from '@angular/router';
import {Config} from '../../config/config';
@Injectable()
export class loginService {
    private id;    
    private apiUrl = Config.API_URL; 
    private isLoggedin:boolean = false;
    constructor(private _http: Http,private route: ActivatedRoute) {}
   
    login(data){          
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var getdata= this._http.get(this.apiUrl+'BookingRequest/UserLogin?userName='+data.userName+'&passWord='+data.passWord,  {headers: headers})
        .map(x => x.json());  
        this.isLoggedin=true;              
        return getdata; 
    }


    isloggedin(){
       return this.isLoggedin;
    }
}

