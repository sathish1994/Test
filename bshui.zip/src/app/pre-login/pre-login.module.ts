import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule, Routes} from '@angular/router';
import { LoginComponent }  from './login/component/login.component';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { loginService } from './loginservice/login-service';
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
@NgModule({
  imports:      [ BrowserModule,RouterModule,HttpModule,SimpleNotificationsModule,FormsModule,ReactiveFormsModule,CommonModule],
  declarations: [ LoginComponent],
  providers: [loginService]
})
export class PreLoginModule { }
