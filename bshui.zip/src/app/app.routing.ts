import { RouterModule } from '@angular/router';
import {LoginComponent} from './pre-login/login/component/login.component';

export const routing = RouterModule.forRoot([
    {                                          // removed square bracket
        path: '',       
        component: LoginComponent
    }, {                                          // removed square bracket
        path: 'login',       
        component: LoginComponent
    }
  ]);