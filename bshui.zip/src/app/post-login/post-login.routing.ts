import { RouterModule } from '@angular/router';
import {DashboardComponent} from './dashboard/component/dashboard.component';
import { BookingRequestComponent }  from './booking-request/component/booking-request.component';
import { BookingRequestListComponent }  from './booking-request/component/booking-request-list.component';
import { EditBookingRequestComponent }  from './booking-request/component/edit-booking-request.component';
import { ALScreen1Component }  from './ashokleyland/component/alscreen1.component';
import { ALScreen2Component }  from './ashokleyland/component/alscreen2.component';
import { BSHComponent }  from './bsh/component/bsh.component';
export const routing = RouterModule.forRoot([   
    {
        path: 'dashboard',
        component: DashboardComponent
    },
    {
        path: 'booking-request',
        component: BookingRequestComponent
    },
    {
        path: 'booking-request-list',
        component: BookingRequestListComponent
    },
    {
        path: 'edit-booking-request/:id',
        component: EditBookingRequestComponent
    },
    {
        path: 'alscreen1',
        component: ALScreen1Component
    },
    {
        path: 'alscreen2',
        component: ALScreen2Component
    },
    {
        path: 'alscreen2',
        component: ALScreen2Component
    },
    {
        path: 'bsh',
        component: BSHComponent
    }
  ]);