import { Component ,OnInit} from '@angular/core';
import * as $ from 'jquery';
import { FormControl,FormGroup, FormBuilder ,Validator} from '@angular/forms';
import { ActivatedRoute,RouterModule , Router ,Params} from '@angular/router';
@Component({
  selector: 'edit-booking-request-template',
  templateUrl: './../template/edit-booking-request.template.html',
  styles:[`
    .mandatory{
        color:red;
    }
  `]
})
export class EditBookingRequestComponent implements OnInit  { 
  date:any;
  bookrequestData:any;
  brid:any;
  formname:any='editinvoiceForm';
  constructor(private activatedRoute: ActivatedRoute,private router: Router){
    this.activatedRoute.params.subscribe((params: Params) => 
    {
     this.brid=params['id'];      
    });
    this.bookrequestData = {
        customer:'',
        location:'',
        date:'',
        parentBr:'',
        sourceLocation:'',
        destinationLocation:'',
        vehicle:'',
        docketNumber:'',
        trackingDevice:'',
        invoice:[{
          invoiceNumber:'',
          invoiceValue:'',
          initialInv:0,
          initialquan:0,
          thuDetail:[{
            thu:'',
            quantity:'',
            thuInfo:''
          }]
        }]
    }
  }
  ngOnInit(){ 
      $("#date").keydown(false);
      $("#loadingdiv").show();
      var data = JSON.parse(localStorage.getItem('bookingRequestData'));      
      this.bookrequestData = data[this.brid];
      setTimeout(() => { 
        this.collapseBlock();
      }, 1000); 
      $("#loadingdiv").hide();
  }

  collapseBlock(){
    this.bookrequestData.invoice.forEach(function(val,index){   
      $('#invoice_collapse_'+index).addClass('collapsed-box');
      $('#invoice_icon_'+index).removeClass('fa-minus');
      $('#invoice_icon_'+index).addClass('fa-plus');
      $("#invoice_box_body_"+index).css("display", "none"); 
      var count = val.thuDetail.length;          
      val.thuDetail.forEach(function(val,thuindex){      
          $('#thurow_'+index+'_'+thuindex).addClass('collapsed-box');
          $('#thu_icon_'+index+'_'+thuindex).removeClass('fa-minus');
          $('#thu_icon_'+index+'_'+thuindex).addClass('fa-plus');
          $('#new_thu_'+index+'_'+thuindex).hide();
          $("#box_body_"+index+'_'+thuindex).css("display", "none");          
          if(count == thuindex+1){           
              $('#new_thu_'+index+'_'+thuindex).show();              
          }
      });
    });
  }
  tab1(id1,id2){  
      if(id1 == 1){
          $('#tab_li_'+id2).removeClass('disabled');
          $('#process_bar').css({"width":'100%'});
      } else{
        $('#process_bar').css({"width":'50%'});
      }   
      $('#tab_li_'+id1).removeClass('active');
      $('#tab_li_'+id2).addClass('active');           
  }

  docketValidation(event){    
    var k = event.charCode;            
      return((k > 48 && k < 58) || k == 0 || k == 48);  
  }
  vehicleValidation(event){    
    var k = event.charCode;
      return((k >= 48 && k <= 57) || (k >= 65 && k <= 90) || (k >= 97 && k <= 122) || k==0); 
  }

  vehicleCaps(val){
    this.bookrequestData.vehicle = val.toUpperCase(); 
  }

  addInvoice(editinvoiceForm){
    if(!editinvoiceForm.valid){
        alert('Please fill the mandatory fields');
        return false;
    }
    $("#loadingdiv").show();
    this.bookrequestData.invoice.push({
      invoiceNumber:'',
      invoiceValue:'',
      initialInv:0,
      initialquan:0,
      thuDetail:[{
        thu:'',
        quantity:'',
        thuInfo:''
      }]
    });     
    var count = this.bookrequestData.invoice.length;     
    this.bookrequestData.invoice.forEach(function(dataval){
        if(dataval.invoiceNumber != ''){
          dataval.initialInv = dataval.invoiceNumber;
        }
        let thu_qty = 0;
        dataval.thuDetail.forEach(function(thuval){
           thu_qty = thu_qty + parseInt(thuval.quantity);             
        });
        if(isNaN(thu_qty)){
          dataval.initialquan = 0;
        }else{
          dataval.initialquan = thu_qty;
        }
        
    });
    localStorage.setItem('invData',JSON.stringify(this.bookrequestData));
    editinvoiceForm.reset();
    this.bookrequestData = JSON.parse(localStorage.getItem('invData'));
    localStorage.removeItem('invData');
    setTimeout(() => {
      this.invoicebind();
    }, 500);  
}

invoicebind(){   
  var count = this.bookrequestData.invoice.length;
  this.bookrequestData.invoice.forEach(function(Invval,index){   
    $('#invoice_collapse_'+index).addClass('collapsed-box');
    $('#invoice_icon_'+index).removeClass('fa-minus');
    $('#invoice_icon_'+index).addClass('fa-plus');
    $("#invoice_box_body_"+index).css("display", "none");      
    var thucnt = Invval.thuDetail.length;
    Invval.thuDetail.forEach(function(val,thuindex){
      $('#thurow_'+index+'_'+thuindex).addClass('collapsed-box');
      $('#thu_icon_'+index+'_'+thuindex).removeClass('fa-minus');
      $('#thu_icon_'+index+'_'+thuindex).addClass('fa-plus');
      $('#new_thu_'+index+'_'+thuindex).hide();
      $("#box_body_"+index+'_'+thuindex).css("display", "none");
      if(thucnt == thuindex+1){
          $('#thurow_'+index+'_'+thuindex).removeClass('collapsed-box');
          $('#thu_icon_'+index+'_'+thuindex).addClass('fa-minus');
          $('#thu_icon_'+index+'_'+thuindex).removeClass('fa-plus');      
          $('#new_thu_'+index+'_'+thuindex).show();
          $("#box_body_"+index+'_'+thuindex).css("display", "block");
      }
    }); 
    if(count == index+1){
        $('#invoice_collapse_'+index).removeClass('collapsed-box');
        $('#invoice_icon_'+index).addClass('fa-minus');
        $('#invoice_icon_'+index).removeClass('fa-plus');
        $("#invoice_box_body_"+index).css("display", "block");
    }
  });
  $("#loadingdiv").hide();
}
addThu(invId,editinvoiceForm){
  if(!editinvoiceForm.valid){
    alert('Please fill the mandatory fields');
    return false;
  }
  $("#loadingdiv").show();
  localStorage.setItem('thuData',JSON.stringify(this.bookrequestData));
  editinvoiceForm.reset();
  this.bookrequestData = JSON.parse(localStorage.getItem('thuData'));
  localStorage.removeItem('thuData');
  this.bookrequestData.invoice[invId].thuDetail.push({
    thu:'',
    quantity:'',
    thuInfo:''
  });    
  setTimeout(() => {
    this.addthubind(invId)
  }, 500);  
}

 addthubind(invId){
  var count = this.bookrequestData.invoice[invId].thuDetail.length;
  var counts = this.bookrequestData.invoice.length;    
  this.bookrequestData.invoice.forEach(function(Invval,index){   
    $('#invoice_collapse_'+index).addClass('collapsed-box');
    $('#invoice_icon_'+index).removeClass('fa-minus');
    $('#invoice_icon_'+index).addClass('fa-plus');
    $("#invoice_box_body_"+index).css("display", "none"); 
    if(invId == index){
        $('#invoice_collapse_'+index).removeClass('collapsed-box');
        $('#invoice_icon_'+index).addClass('fa-minus');
        $('#invoice_icon_'+index).removeClass('fa-plus');
        $("#invoice_box_body_"+index).css("display", "block");
    }
  });
  this.bookrequestData.invoice[invId].thuDetail.forEach(function(val,index){
      $('#thurow_'+invId+'_'+index).addClass('collapsed-box');
      $('#thu_icon_'+invId+'_'+index).removeClass('fa-minus');
      $('#thu_icon_'+invId+'_'+index).addClass('fa-plus');
      $('#new_thu_'+invId+'_'+index).hide();
      $("#box_body_"+invId+'_'+index).css("display", "none");
      if(count == index+1){    
          $('#thurow_'+invId+'_'+index).removeClass('collapsed-box');
          $('#thu_icon_'+invId+'_'+index).addClass('fa-minus');
          $('#thu_icon_'+invId+'_'+index).removeClass('fa-plus');      
          $('#new_thu_'+invId+'_'+index).show();
          $("#box_body_"+invId+'_'+index).css("display", "block");
      }
    });
  $("#loadingdiv").hide();
 } 
 deleteinvoice(id,editinvoiceForm){
  var confirm = window.confirm("Are you sure to delete");
  if(confirm){	
    var count = this.bookrequestData.invoice.length;
    if(count == 1){
      alert('Unable to delete');	
    }else{					
      this.bookrequestData.invoice.splice(id, 1);
      localStorage.setItem('invData',JSON.stringify(this.bookrequestData));
      editinvoiceForm.reset();
      this.bookrequestData = JSON.parse(localStorage.getItem('invData'));
      localStorage.removeItem('invData');
      setTimeout(() => {
        this.invoicebind();
      }, 500);
    }      
  }
}

deleteThu(invId,thuid,editinvoiceForm){
  var confirm = window.confirm("Are you sure to delete");
  if(confirm){	
    var count = this.bookrequestData.invoice[invId].thuDetail.length;
    if(count == 1){
      alert('Unable to delete');	
    }else{	    
      this.bookrequestData.invoice[invId].thuDetail.splice(thuid, 1);
      $("#loadingdiv").show();
      localStorage.setItem('thuData',JSON.stringify(this.bookrequestData));
      editinvoiceForm.reset();
      this.bookrequestData = JSON.parse(localStorage.getItem('thuData'));
      localStorage.removeItem('thuData');
      setTimeout(() => {
        this.addthubind(invId)
      }, 500);
      
    }      
  }
}

  invoiceNumberValidation(event){    
    var k = event.charCode;
      return((k >= 48 && k <= 57) || (k >= 65 && k <= 90) || (k >= 97 && k <= 122) || k == 0 || k == 48 || k == 45 || k == 95 || k == 47);  
  }

  invoicequantityValidation(event){
    var k = event.charCode;
    return((k > 48 && k < 58) || k == 42 || k == 46  || k == 0 || k == 48);
  }

  quantityValidation(event){    
    var k = event.charCode;            
      return((k > 48 && k < 58) || k == 0 || k == 48);  
  }



  updateBr(bookrequestData,editinvoiceForm){
    if(!editinvoiceForm.valid){
      this.bookrequestData.invoice.forEach(function(val,index){
        if(val.invoiceNumber == '' || val.invoiceNumber == null){
          $('#invoice_collapse_'+index).removeClass('collapsed-box');
          $('#invoice_icon_'+index).addClass('fa-minus');
          $('#invoice_icon_'+index).removeClass('fa-plus');
          $("#invoice_box_body_"+index).css("display", "block");
         
        }
        if(val.invoiceValue == '' || val.invoiceValue == null){
          $('#invoice_collapse_'+index).removeClass('collapsed-box');
          $('#invoice_icon_'+index).addClass('fa-minus');
          $('#invoice_icon_'+index).removeClass('fa-plus');
          $("#invoice_box_body_"+index).css("display", "block");
          
        }
        val.thuDetail.forEach(function(thuval,ind){
          if(thuval.quantity == '' || thuval.quantity == null){
              $('#invoice_collapse_'+index).removeClass('collapsed-box');
              $('#invoice_icon_'+index).addClass('fa-minus');
              $('#invoice_icon_'+index).removeClass('fa-plus');
              $("#invoice_box_body_"+index).css("display", "block");

              $('#thurow_'+index+'_'+ind).removeClass('collapsed-box');
              $('#thu_icon_'+index+'_'+ind).addClass('fa-minus');
              $('#thu_icon_'+index+'_'+ind).removeClass('fa-plus');
              $('#new_thu_'+index+'_'+ind).show();
              $("#box_body_"+index+'_'+ind).css("display", "block");            
          }else{            
            var filter = /^\d{0,20}[\.]\d{0,2}$/;
            var data = filter.test(thuval.quantity);            
             if(data == false){
                $('#invoice_collapse_'+index).removeClass('collapsed-box');
                $('#invoice_icon_'+index).addClass('fa-minus');
                $('#invoice_icon_'+index).removeClass('fa-plus');
                $("#invoice_box_body_"+index).css("display", "block");
    
                $('#thurow_'+index+'_'+ind).removeClass('collapsed-box');
                $('#thu_icon_'+index+'_'+ind).addClass('fa-minus');
                $('#thu_icon_'+index+'_'+ind).removeClass('fa-plus');
                $('#new_thu_'+index+'_'+ind).show();
                $("#box_body_"+index+'_'+ind).css("display", "block");
             } 
          }
        });
      });
      alert('Please fill the mandatory fields or valid data');
      return false;
    }
    
    this.bookrequestData.invoice.forEach(function(dataval){
        if(dataval.invoiceNumber != ''){
          dataval.initialInv = dataval.invoiceNumber;
        }
        let thu_qty = 0;
        dataval.thuDetail.forEach(function(thuval){
          thu_qty = thu_qty + parseInt(thuval.quantity);             
        });
        if(isNaN(thu_qty)){
          dataval.initialquan = 0;
        }else{
          dataval.initialquan = thu_qty;
        }      
    });
    console.log(this.bookrequestData)
    var data = JSON.parse(localStorage.getItem('bookingRequestData'));
    data[this.brid]=  '';  
    data[this.brid]=  this.bookrequestData;  
    localStorage.setItem('masterData',JSON.stringify(data));    
    this.router.navigate(['/booking-request-list']);  
  }
}