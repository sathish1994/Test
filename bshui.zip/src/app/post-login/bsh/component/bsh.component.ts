import { Component ,OnInit,Directive} from '@angular/core';

declare var $: any;
import { FormControl,FormGroup, FormBuilder ,Validator} from '@angular/forms';
import {Router,NavigationExtras} from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { PostLoginService } from './../../post-service/service';
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
@Component({
  selector: 'bsh-template',
  templateUrl: './../template/bsh.template.html',
  styles:[`
    .mandatory{
        color:red;
    }
  `]
})

export class BSHComponent implements OnInit  { 
   bshDetails:any;
   docData:any;
   docNum:any;
   code:any;
   qty:any;
   desc:any;
   docType:any;
   sNoData:any;
   validationArray:any;
   location:any;
   pushArray:any;
   orderNumber:any;
   documentNumber:any;
   oldArrayBeforRemove:any;
    constructor(private router: Router,private PostLoginService: PostLoginService,private Http:Http,private NotificationsService:NotificationsService){
          this.bshDetails = {
              docType:'',
              referenceNumber:'',
              orderType:'',
              docStatus:'',
              docDetails:[]
          }
          this.docType='';
          this.code='';
          this.qty='';
          this.desc='';
          this.sNoData='';
          this.validationArray = [];
          this.orderNumber= '';
          this.location =  sessionStorage.getItem('locationCode');
          this.pushArray=[];
          this.documentNumber = '';
          this.oldArrayBeforRemove = [];
    }
    ngOnInit(){
      this.bshDetails = {
        docType:'',
        referenceNumber:'',
        orderType:'',
        docStatus:'',
        docDetails:[]
      }
      this.orderNumber == ''
      this.docType='';
      this.code='';
      this.qty='';
      this.desc='';
      this.sNoData='';
      this.validationArray = [];
      this.oldArrayBeforRemove = [];
      this.orderNumber= '';
      this.pushArray=[];
    }

    resetData(){
      this.bshDetails = {
        docType:'',
        referenceNumber:'',
        orderType:'',
        docStatus:'',
        docDetails:[]
      }
      this.orderNumber == ''
      this.code='';
      this.qty='';
      this.desc='';
      this.sNoData='';
      this.validationArray = [];
      this.oldArrayBeforRemove = [];
      this.orderNumber= '';
      this.pushArray=[];
    }
    getRefModalopen(){
      if( this.docType == '' || this.docType == null || this.docType == 'undefined'){
        alert('Please select doc type.');
      }else{
        $('#loadingdiv').show();
        this.bshDetails = {
          docType:'',
          referenceNumber:'',
          orderType:'',
          docStatus:'',
          docDetails:[]
        }  
        this.documentNumber ='';     
          this.code='';
          this.qty='';
          this.desc='';
          this.sNoData='';
          this.validationArray = [];
          this.orderNumber= '';
          this.pushArray=[];
          this.oldArrayBeforRemove = [];
        var location = sessionStorage.getItem('locationCode');     
        if(this.docType == 'INBOUND'){
          this.PostLoginService.getInboundDocNumber(this.docType,location)
          .subscribe((data) => {            
            $("#myModal").modal('show');
            setTimeout(() => {
              this.dataTable();
            },1000); 
            this.bshDetails.docType = this.docType;
            this.docData = data;
            // this.updateSelection (0) ; 
            $('#loadingdiv').hide();     
          });
        }else{
          this.PostLoginService.getOutboundDocNumber(this.docType,location)
          .subscribe((data) => {            
            $("#myModal").modal('show');
            setTimeout(() => {
              this.dataTable();
            },1000); 
            this.bshDetails.docType = this.docType;
            this.docData = data;
            // this.updateSelection (0) ; 
            $('#loadingdiv').hide();     
          }); 
        } 
      }
    }

    dataTable(){
      $('#get-doc').DataTable({
        "paging":   false});
    }

    getDocData(){    
      this.orderNumber = this.documentNumber;
      if(this.orderNumber == '' || this.orderNumber == null){
        alert('Please select One document number.');
        $('#loadingdiv').hide();   
        return false;
      }
        var docuDetArray = [];
        $('#loadingdiv').show();        
        if(this.docType == 'INBOUND'){
          this.PostLoginService.getInboundOrderDetails(this.docType,this.location,this.orderNumber)
          .subscribe((data) => {       
              data.ItemCode.forEach(function(detalis){
                  var obj = {
                    code:detalis.ItemCode,desc:detalis.ItemDesc,qty:detalis.OrderQty,serialDetails:[],status:detalis.LineStatus,LineNo:detalis.LineNo	
                  };
                  if(data.SerialNumber.length == 0){
                    obj.serialDetails = [];
                  }else{
                    data.SerialNumber.forEach(function(serData){
                        if(obj.code == serData.ItemCode){
                            var obj1 = {serialNumber:serData.SerialNumber};
                            obj.serialDetails.push(obj1);
                        }
                    });
                  }
                  docuDetArray.push(obj);
              });
              var newValidaArray = [];
              data.SerialNumber.forEach(function(serData){
                var new_obj1 = {serialNumber:serData.SerialNumber,code:serData.ItemCode,existMessage:null}
                newValidaArray.push(new_obj1);
              });
              this.validationArray = newValidaArray;
              
              this.bshDetails = {
                  docType :this.docType,
                  referenceNumber:data.DocNumber[0].RefDocNo,
                  orderType:data.DocNumber[0].OrderType,
                  docStatus:data.DocNumber[0].HeaderStatus,
                  docDetails:docuDetArray
              }
              
              $('#get-doc').DataTable().clear().destroy();
              sessionStorage.removeItem('docNumber');
              $("#myModal").modal('hide');
              $('#loadingdiv').hide();
          });
        }else{
          this.PostLoginService.getOutboundOrderDetails(this.docType,this.location,this.orderNumber)
          .subscribe((data) => {       
              data.ItemCode.forEach(function(detalis){
                  var obj = {
                    code:detalis.ItemCode,desc:detalis.ItemDesc,qty:detalis.OrderQty,serialDetails:[],status:detalis.LineStatus,LineNo:detalis.LineNo	
                  };
                  if(data.SerialNumber.length == 0){
                    obj.serialDetails = [];
                  }else{
                    data.SerialNumber.forEach(function(serData){
                        if(obj.code == serData.ItemCode){
                            var obj1 = {serialNumber:serData.SerialNumber};
                            obj.serialDetails.push(obj1);
                        }
                    });
                  }
                  docuDetArray.push(obj);
              });
              var newValidaArray = [];
              data.SerialNumber.forEach(function(serData){
                var new_obj1 = {serialNumber:serData.SerialNumber,code:serData.ItemCode,existMessage:null}
                newValidaArray.push(new_obj1);
              });
              this.validationArray = newValidaArray;
              
              this.bshDetails = {
                  docType :this.docType,
                  referenceNumber:data.DocNumber[0].RefDocNo,
                  orderType:data.DocNumber[0].OrderType,
                  docStatus:data.DocNumber[0].HeaderStatus,
                  docDetails:docuDetArray
              }
              
              $('#get-doc').DataTable().clear().destroy();
              sessionStorage.removeItem('docNumber');
              $("#myModal").modal('hide');
              $('#loadingdiv').hide();
          });
        }
        
    }
    getRefModalclose(){
      $('#get-doc').DataTable().clear().destroy();
      sessionStorage.removeItem('docNumber');
      $("#myModal").modal('hide');
      
    }
    serialNumData:any;
    addQty:any;
    getSnoModalopen(val,code,qty,desc,serialData,actualData){  
      this.code=code;
      this.qty=qty;
      this.desc=desc; 
      this.addQty = serialData.length;
      sessionStorage.setItem('actualdata',JSON.stringify(actualData)) ;
      this.serialNumData = serialData;      
      $("#myModal2").modal('show');
    }
    

   updateSelection (position) {    
    this.documentNumber = '';
    this.docData.forEach(function(data, index) {
          if (position != index){
            data.selectData = false;           
          }else{ 
            sessionStorage.setItem('docNumber', data.OrderNo);            
          }
        });
        this.documentNumber =sessionStorage.getItem('docNumber');
        sessionStorage.removeItem('docNumber');
        $('#loadingdiv').hide();
    }
    
    addSerialNum(sNoData,serialNumData,codeno,qty){      
        if(sNoData == '' || sNoData == null || sNoData == 'undefined'){
            alert('Please enter serial Number');
        }else if(qty == serialNumData.length){
          alert("Maximum quantity reached.");
        }else{  
          console.log(this.validationArray);
          var pushArray = []; 
          var validObj = {serialNumber:sNoData,code:'',existMessage:null};      
          if(serialNumData.length == 0){
              var new_obj = {serialNumber:sNoData}
              this.serialNumData.reverse();
              this.serialNumData.push(new_obj);
              this.serialNumData.reverse();
              if(this.validationArray.length == 0){
                var new_obj1 = {serialNumber:sNoData,code:codeno,existMessage:null}
                this.validationArray.push(new_obj1);               
              }else{
                validObj= {serialNumber:sNoData,code:codeno,existMessage:null};
                pushArray.push(validObj);
                this.validationArray.forEach(function(validData){
                    if(validData.serialNumber == sNoData){
                      var message = 'Serial Number '+sNoData+' is already exist on code '+validData.code;
                      validObj = {serialNumber:sNoData,code:codeno,existMessage:message};
                      pushArray.push(validObj)  
                    }
                });
              }
              this.sNoData = '';
          }else{
            //alert('12'); 
            var isExist = 0;
            this.serialNumData.forEach(function(vData){
                if(vData.serialNumber == sNoData){
                  isExist = 1;
                }
            });
            if(isExist == 1){
                alert('Serial number '+sNoData +' already exist for this code '+codeno);
                this.sNoData = '';
            }else{
                var new_obj = {serialNumber:sNoData};
                this.serialNumData.reverse();
                this.serialNumData.push(new_obj);
                this.serialNumData.reverse();
                if(this.validationArray.length == 0){
                  var new_obj3 = {serialNumber:sNoData,code:codeno,existMessage:null}
                  this.validationArray.push(new_obj3);               
                }else{
                  validObj = {serialNumber:sNoData,code:codeno,existMessage:null};   
                  pushArray.push(validObj)
                  this.validationArray.forEach(function(validData){                     
                      if(validData.serialNumber == sNoData){
                        var message1 = 'Serial Number '+sNoData+' is already exist on code '+validData.code;
                        validObj = {serialNumber:sNoData,code:codeno,existMessage:message1};
                        pushArray.push(validObj) 
                      }
                      
                  });
                } 
                this.sNoData = '';
            }
           
          }     
          this.validationArray.forEach(function(data){
              pushArray.push(data);
          });
          this.validationArray = pushArray;
         
        } 
         this.addQty =    serialNumData.length;
         this.sNoData = '';
         $('#s_no').val('');
        //  $("#s_no").focus();
         
        
    }
    
    removeSerialNum(ind,arryData,sno,code){
      var confirm =  window.confirm("Are you sure to delete");    
    if(confirm){ 
      this.oldArrayBeforRemove=arryData;
      var new_array = [];
      var newvalidationarray = [];
      arryData.forEach(function(val,index){          
          if(index == ind){
            val.serialNumber = '';
          }else{
            new_array.push(val);
          }
      });
      this.validationArray.forEach(function(remData){        
        if(remData.serialNumber != sno || remData.code != code){
            newvalidationarray.push(remData);
        }
      });   
      this.serialNumData =new_array;
      this.addQty = this.serialNumData.length;
      this.validationArray = newvalidationarray;
    }
    }

    pushSerialNum(code,serialNumData){
      this.bshDetails.docDetails.forEach(function(sData,index){
          if(code == sData.code){
              sData.serialDetails = [];
              serialNumData.forEach(function(snData){
                sData.serialDetails.push(snData);
              });             
          }
      });     
      $('#s_no').val('');
      this.sNoData = '';
      $("#myModal2").modal('hide');
    }

    getsnoModalclose(code){
     var serialNumData = JSON.parse(sessionStorage.getItem('actualdata')) ;
      this.bshDetails.docDetails.forEach(function(sData,index){
          if(code == sData.code){
              sData.serialDetails = [];
              serialNumData.forEach(function(snData){
                sData.serialDetails.push(snData);
              });             
          }
      }); 
      $("#myModal2").modal('hide');
      $('#s_no').val('');
      sessionStorage.removeItem('actualdata');
      this.sNoData = '';
    }
    validDiv:boolean=false;
    bindvalidationArray = [];

    confimation(){
      $('#loadingdiv').show();
      if( this.docType == '' || this.docType == null || this.docType == 'undefined'){
          alert('Please select doc type.');
          $('#loadingdiv').hide();
      }else{

      
      var newValidationArray = []
        this.validationArray.forEach(function(vData){
            if(vData.existMessage != null){
              var sData = vData.code+' - '+vData.existMessage;
              newValidationArray.push(sData);
            }
        });
        console.log(newValidationArray.length);
      if(newValidationArray.length != 0){
        
        var uniqueValidationArray = [];
        $.each(newValidationArray, function(i, el){
            if($.inArray(el, uniqueValidationArray) === -1) uniqueValidationArray.push(el);
        });
        this.bindvalidationArray = uniqueValidationArray;
        this.validDiv =true;      
        
        $('#loadingdiv').hide();
      }else{
        this.validDiv =false; 
        var custLine = [];
        var location = this.location;
        var orderNumber =this.orderNumber;
        this.bshDetails.docDetails.forEach(function(docData){
            var new_obj = {Location:location,OrderNo:orderNumber,CustomerLineNo:docData.LineNo,ItemCode :docData.code,SerialNo:{SNo:''}};
            if(docData.serialDetails.length != 0){
              var obj1 = '';
                docData.serialDetails.forEach(function(serialData){
                    obj1 += serialData.serialNumber+',';                    
                });
                new_obj.SerialNo.SNo = obj1.substring(0, obj1.length - 1);;
            }else{
              new_obj.SerialNo.SNo = '';
            }
            custLine.push(new_obj);
        }); 
        var finalConfirm = {};
        if(this.bshDetails.docType == 'INBOUND'){
          finalConfirm = {'Inbound':{Order:custLine}};
          this.PostLoginService.confirmInboundBsh(finalConfirm)
          .subscribe((data) => { 
              if(data == 'Success'){
                this.NotificationsService.success('BSH','BSH Added Successfully.',{timeOut: 2000, clickToClose: true});
                this.ngOnInit();
                $('#loadingdiv').hide();
                
              }else{
                this.NotificationsService.error('BSH','BSH Added Unsuccessfully.',{timeOut: 2000, clickToClose: true});
                this.ngOnInit();
                $('#loadingdiv').hide();
              }          
            });
        }else{
          finalConfirm = {'Outbound':{Order:custLine}};
          this.PostLoginService.confirmOutboundBsh(finalConfirm)
          .subscribe((data) => { 
              if(data == 'Success'){
                this.NotificationsService.success('BSH','BSH Added Successfully.',{timeOut: 2000, clickToClose: true});
                this.ngOnInit();
                $('#loadingdiv').hide();
                
              }else{
                this.NotificationsService.error('BSH','BSH Added Unsuccessfully.',{timeOut: 2000, clickToClose: true});
                this.ngOnInit();
                $('#loadingdiv').hide();
              }          
            });
        } 
        
      }
      }
        
    }

    cancelConfirm(){
      this.ngOnInit();
    }
}