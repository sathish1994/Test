import { Component ,OnInit,AfterViewInit} from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import * as $ from 'jquery';
import 'datatables.net';

import { PostLoginService } from './../../post-service/service';
import {Router,NavigationExtras} from '@angular/router';
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
@Component({
  selector: 'bsh-list-template',
  templateUrl: './../template/bsh-list.template.html',
})
export class BSHListComponent implements OnInit {
  
  masterData:any;
  constructor(private http: Http,private PostLoginService:PostLoginService,private router: Router,private _notifications: NotificationsService) {
	
  }
 
  public tableWidget:any;
  ngAfterViewInit() {
    setTimeout(() => {
      this.initDatatable()
    }, 1000);
  
  }  
  initDatatable(){
    let exampleId: any = $('#newmaster-list');
    this.tableWidget = exampleId.DataTable();
    $("#loadingdiv").hide();
  }

  ngOnInit() {
    $("#loadingdiv").show();
    var data = JSON.parse(localStorage.getItem('bookingRequestData'));
    
   
    this.masterData= data;
    console.log(this.masterData)
    $("#loadingdiv").hide();
  }
  editnewmaster(id){
      this.router.navigate(['/edit-booking-request/'+id]); 
  }
  deletemaster(id){
    var confirm = window.confirm("Are you sure to delete");
    if(confirm){
        $("#loadingdiv").show();
        var new_array = JSON.parse(localStorage.getItem('bookingRequestData'));
        new_array.splice(id, 1);     
        localStorage.setItem('bookingRequestData',JSON.stringify(new_array));
        this.ngOnInit();
    }    
  }
}
