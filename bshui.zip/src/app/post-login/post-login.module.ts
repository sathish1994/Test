import { NgModule }      from '@angular/core';
import { DatePipe}      from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule, Routes} from '@angular/router';
import { routing } from './post-login.routing';
import { HttpModule } from '@angular/http';
import { Select2Module } from 'ng2-select2';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PostLoginService } from './post-service/service';
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
import { DashboardComponent }  from './dashboard/component/dashboard.component';
import { BookingRequestComponent }  from './booking-request/component/booking-request.component';
import { BookingRequestListComponent }  from './booking-request/component/booking-request-list.component';
import { EditBookingRequestComponent }  from './booking-request/component/edit-booking-request.component';
import { OnlyNumber }  from './booking-request/component/validation';
import { ALScreen1Component }  from './ashokleyland/component/alscreen1.component';
import { ALScreen2Component }  from './ashokleyland/component/alscreen2.component';
import { BSHComponent }  from './bsh/component/bsh.component';
@NgModule({
  imports:      [ BrowserModule,RouterModule ,routing,HttpModule,FormsModule,ReactiveFormsModule,SimpleNotificationsModule,Select2Module],
  declarations: [ DashboardComponent,BookingRequestComponent,BSHComponent,BookingRequestListComponent,EditBookingRequestComponent,OnlyNumber,ALScreen1Component,ALScreen2Component],
 
  providers: [PostLoginService,DatePipe]
})
export class PostLoginModule { }
