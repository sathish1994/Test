import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { ActivatedRoute } from '@angular/router';
import {Config} from '../../config/config';
@Injectable()
export class PostLoginService {   
    private id;   
    private apiUrl = Config.API_URL;  
    sub:any;
    constructor(private _http: Http,private route: ActivatedRoute) {}
    customerList(){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetCustomer',{headers: headers})
        .map(x => x.json());       
        return res;
    }

    locationList(id){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetLocation?ramcoId='+id,{headers: headers})
        .map(x => x.json());       
        return res;
    }
    GetBRCode(ramcoId, locationCode,fromDate){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetBRCode?ramcoId='+ramcoId+'&locationCode='+locationCode+'&fromDate='+fromDate,{headers: headers})
        .map(x => x.json());       
        return res;
    }
    GetBRCodeUnique(){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetSavedBRCodeUnique',{headers: headers})
        .map(x => x.json());       
        return res;
    }
    GetAddressDetails(ramcoId, locationCode,fromDate,brNumber){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetAddressDetails?ramcoId='+ramcoId+'&locationCode='+locationCode+'&fromDate='+fromDate+'&brNumber='+brNumber,{headers: headers})
        .map(x => x.json());       
        return res;
    }
    GetThu(){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetThu',{headers: headers})
        .map(x => x.json());       
        return res;
    }  
    
    startTrip(userName,bookrequestData){
        let headers = new Headers();  
        headers.append('Content-Type', 'application/json');  
        var res=this._http.post(this.apiUrl+'BookingRequest/StartTrip?userName='+userName, JSON.stringify(bookrequestData),{headers: headers})
        .map(x => x.json());       
        return res;
    }  

    getAlscreen1(waveNo, serialNo){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetALValidationStage1?waveNo='+waveNo+'&serialNo='+serialNo,{headers: headers})
        .map(x => x.json());       
        return res;
    }

    getAlscreen2(waveNo, stageId){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetALValidationStage2?waveNo='+waveNo+'&stageId='+stageId,{headers: headers})
        .map(x => x.json());       
        return res;
    }

    createAlScreen1(data){
        let headers = new Headers();  
        headers.append('Content-Type', 'application/json');  
        var res=this._http.post(this.apiUrl+'BookingRequest/SaveALStage1', JSON.stringify(data),{headers: headers})
        .map(x => x.json());       
        return res;
    }
    createAlScreen2(data){
        let headers = new Headers();  
        headers.append('Content-Type', 'application/json');  
        var res=this._http.post(this.apiUrl+'BookingRequest/SaveALStage2', JSON.stringify(data),{headers: headers})
        .map(x => x.json());       
        return res;
    }

    getInboundDocNumber(docType,location){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetInboundDocType?dockType='+docType+'&locCode='+location,{headers: headers})
        .map(x => x.json());       
        return res;   
    }
    getOutboundDocNumber(docType,location){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetOutboundDocType?dockType='+docType+'&locCode='+location,{headers: headers})
        .map(x => x.json());       
        return res;   
    }
    getInboundOrderDetails(docType,location,orderNo){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetInboundOrderQuantity?dockType='+docType+'&locCode='+location+'&orderNo='+orderNo,{headers: headers})
        .map(x => x.json());       
        return res;   
    }
    getOutboundOrderDetails(docType,location,orderNo){
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');  
        var res=this._http.get(this.apiUrl+'BookingRequest/GetOutboundOrderQuantity?dockType='+docType+'&locCode='+location+'&orderNo='+orderNo,{headers: headers})
        .map(x => x.json());       
        return res;   
    }

    confirmInboundBsh(data){
        let headers = new Headers();  
        headers.append('Content-Type', 'application/json');  
        var res=this._http.post(this.apiUrl+'BookingRequest/ConfirmInboundBSH', JSON.stringify(data),{headers: headers})
        .map(x => x.text());       
        return res;
    }
    confirmOutboundBsh(data){
        let headers = new Headers();  
        headers.append('Content-Type', 'application/json');  
        var res=this._http.post(this.apiUrl+'BookingRequest/ConfirmOutboundBSH', JSON.stringify(data),{headers: headers})
        .map(x => x.text());       
        return res;
    }
}

