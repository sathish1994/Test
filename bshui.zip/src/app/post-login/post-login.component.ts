import { Component ,OnInit} from '@angular/core';
import { RouterModule } from '@angular/router';
import { DashboardComponent }  from './dashboard/component/dashboard.component';
import { BookingRequestComponent }  from './booking-request/component/booking-request.component';
import { BookingRequestListComponent }  from './booking-request/component/booking-request-list.component';
import { EditBookingRequestComponent }  from './booking-request/component/edit-booking-request.component';
import { ALScreen1Component }  from './ashokleyland/component/alscreen1.component';
import { ALScreen2Component }  from './ashokleyland/component/alscreen2.component';
declare var $: any;
@Component({
})
export class PostLoginComponent{ 
 
}
