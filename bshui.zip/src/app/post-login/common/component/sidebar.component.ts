import { Component,OnInit } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/interval';
import {Subscription} from 'rxjs/Subscription';
declare var $: any;
@Component({
  selector: 'sidebar-template',
  templateUrl: './../template/sidebar.template.html',
})
export class SidebarComponent implements OnInit {
  menuData:any;
  constructor(){  }
    ngOnInit(){
        this.menuData = JSON.parse(localStorage.getItem('menu'));
    }
    mouseEnter(){
        $('body').removeClass('sidebar-collapse');
        $('body').addClass('sidebar-expanded-on-hover');
    }
    mouseLeave(){
      if (!$("body").hasClass("dummy-class")) {
        $('body').addClass('sidebar-collapse');
        $('body').removeClass('sidebar-expanded-on-hover');
      }        
    }

    menu_active(){
     
      var header = document.getElementById("sidemenu");
      var btns = header.getElementsByClassName("menu-class");
      for (var i = 0; i < btns.length; i++) {
        btns[i].addEventListener("click", function() {
          var current = document.getElementsByClassName("active");
          current[0].className = current[0].className.replace(" active", "");
          this.className += " active";
        });
      }
     
    }
}
