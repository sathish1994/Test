import { Component } from '@angular/core';

@Component({
  selector: 'footer-template',
  templateUrl: './../template/footer.template.html',
})
export class FooterComponent  {  }