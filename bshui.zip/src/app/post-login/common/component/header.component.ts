import { Component ,OnInit} from '@angular/core';
declare var $: any;
import {Router} from '@angular/router';
@Component({
  selector: 'header-template',
  templateUrl: './../template/header.template.html',
})
export class HeaderComponent implements OnInit { 
  username:any;
    constructor(private _router: Router){
       var uName= sessionStorage.getItem('userName');
       this.username = uName[0].toUpperCase() + uName.substr(1).toLowerCase();
    }
      
    toggle_sidemenu(){        
        $('body').toggleClass('sidebar-collapse');
        $('body').toggleClass('dummy-class');
        $('body').toggleClass('sidebar-open');
    }  
    ngOnInit(){
      $('body').addClass('skin-blue sidebar-mini sidebar-collapse'); 
      $('body').removeClass('login-page');
    }
    logout(){   
        // $('body').removeClass('login-page');   
        this._router.navigate(['']);
        sessionStorage.setItem('isloggedin','false'); 
        localStorage.removeItem('menu');
        $('body').removeClass('skin-blue sidebar-mini sidebar-collapse'); 
        $('body').addClass('login-page');     
      }
 }