import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'dashboard-template',
  templateUrl: './../template/dashboard.template.html',
})
export class DashboardComponent  implements OnInit { 
menuData:any;
    ngOnInit(){
        this.menuData = JSON.parse(localStorage.getItem('menu'));
    }
 }