import { Component ,OnInit} from '@angular/core';

declare var $: any;
import { FormControl,FormGroup, FormBuilder ,Validator} from '@angular/forms';
import {Router,NavigationExtras} from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { PostLoginService } from './../../post-service/service';
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
@Component({
  selector: 'alscreen1-template',
  templateUrl: './../template/alscreen1.template.html',
  styles:[`
    .mandatory{
        color:red;
    }
  `]
})
export class ALScreen1Component  { 
    alData:any;
    constructor(private router: Router,private PostLoginService: PostLoginService,private Http:Http,private NotificationsService:NotificationsService){
        this.alData = {
            validation:'',
            wave_Number:null,
            thu_Serial_No:null,
            pack_No:null,
            location:null,
            locations:null,
            confirm_Location:null,
            status:null,
            message:''
        }
    }
    
    getWaveDetails(){
        if(this.alData.wave_Number == null || this.alData.wave_Number == ''){
            alert('Please enter Wave Number');
            this.alData = {
                validation:'',
                wave_Number:null,
                thu_Serial_No:null,
                pack_No:null,
                location:null,
                locations:null,
                confirm_Location:null,
                status:null,
                message:''
            }
        }else{
            if(this.alData.thu_Serial_No != null || this.alData.thu_Serial_No == ''){
                this.PostLoginService.getAlscreen1('1231','1212')
                .subscribe((data) => {                     
                    this.alData.pack_No = data[0].Pack_No;                    
                    if(data[0].Stage1_ID == null || data[0].Stage1_ID == ''){                        
                        this.alData.locations = null;
                        this.alData.location = '';
                    }else{
                        this.alData.locations = '';
                        this.alData.location = data[0].Stage1_ID;
                    }        
                    this.alData.validation = data[0].Msg_ID;     
                    this.alData.confirm_Location = null;
                    this.alData.status = data[0].Msg_Desc;
                    this.alData.message = data[0].Msg_Desc;                    
                    if(data[0].Msg_ID == '0000'){                        
                        $('#statusMessage').removeClass('text-green');
                        $('#statusMessage').addClass('text-red');                        
                    }else if(data[0].Msg_ID == '0001'){                       
                        $('#statusMessage').removeClass('text-red');
                        $('#statusMessage').addClass('text-green'); 
                    }else{                        
                        $('#statusMessage').removeClass('text-red');
                        $('#statusMessage').addClass('text-orange'); 
                        $('#myModal').modal('show');                        
                    }                             
                });
            }
        }        
    }  

    createWave(){        
        if(this.alData.location == this.alData.confirm_Location){
            var waveData = {waveNo:null,thuNo:null,stageId:null,userName:null};
            waveData.waveNo = this.alData.wave_Number;
            waveData.thuNo = this.alData.thu_Serial_No;
            waveData.stageId = this.alData.location;
            waveData.userName = sessionStorage.getItem('userName');
            this.PostLoginService.createAlScreen1(waveData)
            .subscribe((data) => { 
                if(data[0].Msg_ID == '0000'){                        
                    alert(data[0].Msg_Desc);                      
                }else if(data[0].Msg_ID == '0001'){                       
                    alert(data[0].Msg_Desc);  
                    this.alData = {
                        wave_Number:null,
                        thu_Serial_No:null,
                        pack_No:null,
                        location:null,
                        locations:null,
                        confirm_Location:null,
                        status:null,
                        message:'',
                        validation:'',
                    } 
                }else{                        
                    alert(data[0].Msg_Desc);                          
                }
            });
        }else{
            alert('Confirm location is incorrect');
            return false;
        }    
        
    }
}