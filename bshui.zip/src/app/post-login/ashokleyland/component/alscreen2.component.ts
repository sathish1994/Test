import { Component ,OnInit} from '@angular/core';

declare var $: any;
import { FormControl,FormGroup, FormBuilder ,Validator} from '@angular/forms';
import {Router,NavigationExtras} from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { PostLoginService } from './../../post-service/service';
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
@Component({
  selector: 'alscreen2-template',
  templateUrl: './../template/alscreen2.template.html',
  styles:[`
    .mandatory{
        color:red;
    }
  `]
})
export class ALScreen2Component implements OnInit  { 
    alData:any;
    constructor(private router: Router,private PostLoginService: PostLoginService,private Http:Http,private NotificationsService:NotificationsService){
        this.alData = {
            wave_Number:null,
            no_Of_Packs:null,
            location:null,
            target_Location:null,
            message:'',
            validation:''
        }
    }
    ngOnInit(){    
      this.PostLoginService.customerList()
      .subscribe((data) => {    
            data.forEach(function(val){
                val.customerCode = val.customerName+'^'+val.romcoID;
            });
               
      });
    }
    getWaveDetails(){
        if(this.alData.wave_Number == null || this.alData.wave_Number == ''){
            alert('Please enter Wave Number');
            this.alData = {
                wave_Number:null,
                no_Of_Packs:null,
                location:null,
                target_Location:null,
                message:'',
                validation:'',
            }
        }else{           
            if(this.alData.wave_Number != null || this.alData.wave_Number == ''){
                this.PostLoginService.getAlscreen2('1231','1212')
                .subscribe((data) => {                     
                    this.alData.no_Of_Packs = data[0].Pack_No;  
                    this.alData.location = data[0].Stage1_ID;
                    this.alData.target_Location = null;
                    this.alData.message = data[0].Msg_Desc;       
                    this.alData.validation = data[0].Msg_ID;             
                    if(data[0].Msg_ID == '0000'){                        
                        $('#statusMessage').removeClass('text-green');
                        $('#statusMessage').addClass('text-red');                        
                    }else if(data[0].Msg_ID == '0001'){                       
                        $('#statusMessage').removeClass('text-red');
                        $('#statusMessage').addClass('text-green'); 
                    }else{                        
                        $('#statusMessage').removeClass('text-red');
                        $('#statusMessage').addClass('text-orange'); 
                        $('#myModal').modal('show');                        
                    }                             
                });
            }
        }        
    }
    createWave(){       
        var waveData = {waveNo:null,stageId1:null,stageId2:null,userName:null};
        waveData.waveNo = this.alData.wave_Number;
        waveData.stageId1 = this.alData.location;
        waveData.stageId2 = this.alData.target_Location;
        waveData.userName = sessionStorage.getItem('userName');
        this.PostLoginService.createAlScreen2(waveData)
        .subscribe((data) => { 
            if(data[0].Msg_ID == '0000'){                        
                alert(data[0].Msg_Desc);                      
            }else if(data[0].Msg_ID == '0001'){                       
                alert(data[0].Msg_Desc);  
                this.alData = {
                    wave_Number:null,
                    no_Of_Packs:null,
                    location:null,
                    target_Location:null,
                    message:'',
                    validation:'',
                } 
            }else{                        
                alert(data[0].Msg_Desc);                          
            }
        });           
       
    } 
}