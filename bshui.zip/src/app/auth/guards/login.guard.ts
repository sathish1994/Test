import {CanActivate, Router} from '@angular/router';
import {Injectable} from '@angular/core';

import { loginService } from './../../pre-login/loginservice/login-service';

@Injectable()
export class LoggedInGuard implements CanActivate {
  constructor(private loginService: loginService, private _router: Router){

  }
  canActivate(){
    return this.loginService.isloggedin();
  }
}
