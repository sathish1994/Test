import { NgModule } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule, Routes} from '@angular/router';
import {HttpModule} from '@angular/http';

import { LoggedInGuard } from './guards/login.guard';

import { loginService } from './../pre-login/loginservice/login-service';

@NgModule({
  imports: [
    BrowserModule,
      RouterModule,
      HttpModule
  ],
  providers: [
    LoggedInGuard,
  ]
})
export class AuthModule {

}
export { LoggedInGuard } from './guards/login.guard';
export { loginService } from './../pre-login/loginservice/login-service';