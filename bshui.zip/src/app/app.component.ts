import { Component ,OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/interval';
import { RouterModule ,Router} from '@angular/router';
import { LoginComponent }  from './pre-login/login/component/login.component';
import { HeaderComponent }  from './post-login/common/component/header.component';
import { FooterComponent }  from './post-login/common/component/footer.component';
import { SidebarComponent }  from './post-login/common/component/sidebar.component';
import {loginService} from './auth/auth.module';
declare var $: any;
@Component({
  selector: 'app-root',
  template: ` <div class="wrapper"> <header-template *ngIf="islogged == true"></header-template> 
  <sidebar-template *ngIf="islogged == true"></sidebar-template>  
  <router-outlet></router-outlet>
  <footer-template *ngIf="islogged == true"></footer-template></div>`, 
})
export class AppComponent implements OnInit { 

  islogged:any = false;
  islogin:any = false;
  constructor(private loginService: loginService,private Router:Router){
    
        }
    ngOnInit(){ 
      Observable.interval(1000).subscribe(() => {        
        this.islogged = this.loginService.isloggedin();
        this.islogin = sessionStorage.getItem('isloggedin');        
        if(this.islogin  == 'false'){
          this.islogged = false;
        }else{
          this.islogged = true;
        }
        if(this.islogged != true && this.islogin == 'false'){
          this.Router.navigate(['']);           
          $('body').removeClass('skin-blue sidebar-mini fixed sidebar-collapse'); 
          $('body').addClass('login-page'); 
        }
      });
    }
 }
