import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule} from '@angular/router';
import { AppComponent }  from './app.component';
import { LoginComponent }  from './pre-login/login/component/login.component';
import { routing } from './app.routing';
import { CommonModule } from '@angular/common';
import { PostLoginModule } from './post-login/post-login.module';
import { HeaderComponent }  from './post-login/common/component/header.component';
import { FooterComponent }  from './post-login/common/component/footer.component';
import { SidebarComponent }  from './post-login/common/component/sidebar.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { loginService } from './pre-login/loginservice/login-service';
import {SimpleNotificationsModule, NotificationsService} from 'angular2-notifications';
import {AuthModule} from './auth/auth.module';
@NgModule({
  imports:      [ BrowserModule,RouterModule,routing,SimpleNotificationsModule,CommonModule,PostLoginModule,ReactiveFormsModule,AuthModule,FormsModule ],
  declarations: [ AppComponent,LoginComponent,HeaderComponent,FooterComponent,SidebarComponent],
  bootstrap:    [ AppComponent ],
  providers: [loginService]
})
export class AppModule {
 
}
