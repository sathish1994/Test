export class Config{
    public static get API_URL(){             
        //return "http://stage.proconnect.in/BookingRequestAPI/api/";
        return "http://stage.proconnect.in/BSHAPI/api/";        
    }
}
  